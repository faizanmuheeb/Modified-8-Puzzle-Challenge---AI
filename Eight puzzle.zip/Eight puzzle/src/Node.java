import java.util.*;

public class Node {

	// Variable declaration: Book keeping information for the puzzle.
	public Node parent;
	public List<Node> children = new  LinkedList<Node>(); // LinkedList to store the children of the nodes.
	public int start = 0; 
	public int[] puzzle = new int[9];    //puzzle stored in a one dimensional integer array.
	public String move; 				//is a string with values LEFT, RIGHT, TOP, BOTTOM
	public int cost = 0; 			   //cost = integer value of the tile being moved.
	public int nodeDepth;			  // Depth of the node
	public int totalCost;		     // variable to store the cumulative cost.
	
	
	// *Constructor node to initialize a node
	public Node(int[] puzzle2) {
		SetPuzzle(puzzle2);
		this.nodeDepth = 0;
		this.cost = 0;
		this.totalCost = 0;
	}
	
	// *Set puzzle and move
	public void SetPuzzle(int[] puzzle2){
		for(int i=0; i<puzzle.length; i++){
			this.puzzle[i] = puzzle2[i];
		}
		this.move = null;	
	}
	
	// *Get parent of a node
	public Node getParent(){
		return this.parent;
	}
	
	// *Set parent of a node
	public void setParent(Node child){
		this.parent = child;
	}
	
	// *Set cost of a node
	public void setCost(int i){
		cost = i; 
	}
	
	// *Return cost of the node
	public int getCost(){
		return this.cost;
	}
	
	// *Return cost of the node
	public int getTotalCost(){
		return this.totalCost;
	}
	
	// *Set depth
	public void setDepth(int i){
		nodeDepth = i;
	}
	
	// *Get depth
	public int getDepth(){
		return this.nodeDepth;
	}
	
	
	// *Verify if a node is goal node
	public Boolean isGoal() {
		boolean isGoal = true; 
		int [] goalpuzzle = {1,2,3,8,0,4,7,6,5};
		for(int i=0; i<puzzle.length; i++){
				if(puzzle[i] != goalpuzzle[i])
				isGoal = false;
			}	
		return isGoal;
	}
	
	// *Moveleft: Moves the position of '0' to left in the puzzle. Done by copying the puzzle into another array.
	//		Then value of the tile is on the left is stored in a temp variable and swapped with '0'.
	public void MoveLeft(int[] p){
		int i=0;
		for(int x=0; x<p.length; x++){		//find index position of 0 in the puzzle
			if(p[x] == 0)
				i=x;
		}
		if(i%3 != 0){ 					// Will not move left if position of 0 is 0,3,6.
			int[] p1= new int[9];
			for(int j=0; j<p.length ; j++)
				p1[j] = p[j];
			
			int tempValue = p1[i-1];
			p1[i-1] = p1[i];
			p1[i] = tempValue;
			
			Node child = new Node(p1);
			children.add(child); 				//add this new state of node to children list
			child.setParent(this.parent); 		//set parent of this child
			child.move = "LEFT"; 				//set movement and cost.
			child.setCost(tempValue);
		}
	}
	
	// *MoveRight: Moves the position of '0' to right in the puzzle. Done by copying the puzzle into another array.
	//		Then value of the tile is on the right is stored in a temp variable and swapped with '0'.
	public void MoveRight(int[] p){
		int i=0;
		
		for(int x=0; x<p.length; x++){
			if(p[x] == 0)
				i=x;
		}

		if(i%3 <2)  						// Will not move right if position of 0 is 2,5,8
		{
			int[] p1= new int[9];
			for(int j=0; j<p.length ; j++)
				p1[j] = p[j];
			
			int tempValue = p1[i+1];
			p1[i+1] = p1[i];
			p1[i] = tempValue;
			
			Node child = new Node(p1);
			children.add(child);				//add this new state of node to children list.
			child.setParent(this.parent);		//set parent of this child
			child.move = "RIGHT";				//set movement and cost.
			child.setCost(tempValue);
		}   
	}
	
	
	// *MoveTop: Moves the position of '0' to the top in the puzzle. Done by copying the puzzle into another array.
	//		Then value of the tile is on the top is stored in a temp variable and swapped with '0'.

	public void MoveTop(int[] p){
		int i=0;
		for(int x=0; x<p.length; x++){
			if(p[x] == 0)
				i=x;
		}
		if(i > 2){								// Will only move up if 0 is in 2nd or 3rd row.
			int[] p1= new int[9];
			for(int j=0; j<p.length ; j++)
				p1[j] = p[j];
			
			int tempValue = p1[i-3];
			p1[i-3] = p1[i];
			p1[i] = tempValue;
			
			Node child = new Node(p1);
			children.add(child);				//add this new state of node to children list.
			child.setParent(this.parent);		//set parent of this child
			child.move = "TOP";					//set movement and cost.
			child.setCost(tempValue);
		}
	}
	
	// *MoveBottom: Moves the position of '0' to the bottom in the puzzle. Done by copying the puzzle into another array.
	//		Then value of the tile is on the bottom is stored in a temp variable and swapped with '0'.
	public void MoveBottom(int[] p){
		int i=0;
		for(int x=0; x<p.length; x++){
			if(p[x] == 0)
				i=x;
		}

		if(i<6){								// Will only move down if 0 is in 1st or 2nd row.
			int[] p1= new int[9];
			for(int j=0; j<p.length ; j++)
				p1[j] = p[j];
			
			int tempValue = p1[i+3];
			p1[i+3] = p1[i];
			p1[i] = tempValue;
			
			Node child = new Node(p1);
			children.add(child);				//add this new state of node to children list.
			child.setParent(this.parent);		//set parent of this child
			child.move = "BOTTOM";				//set movement and cost.
			child.setCost(tempValue);		
		}
	
	}
	
	// *puzzleCopy: Method to copy a puzzle.
	public void puzzleCopy(int x[], int y[]) {
		for (int i=0; i<x.length; i++) {
			x[i] = y[i];
		}
	}
	
	// *ExpandCurrentNode(): This method calls all the move methods, based on the position of 0, appropriate moves
	//						 are executed and the resulting nodes are added as children to that node.
	public void ExpandCurrentNode(){
		MoveTop(puzzle);
		MoveBottom(puzzle);
		MoveRight(puzzle);
		MoveLeft(puzzle);	
	}
	
	
	// *IsEqualPuzzle(int p[]): Check if two puzzles are equal
	public boolean IsEqualPuzzle(int p[]){
		boolean isEqualP = true;
		for(int i=0; i<p.length;i++)
			if(p[i] != puzzle[i])
				isEqualP = false;	
		return isEqualP;
	}
	
	// *misMatchCost(): Method to calculate cost of the tiles that do not match the goal state. (Heuristic-h1)
	public int misMatchCost()
	{
		int count=0;
		int p [] = {1,2,3,8,0,4,7,6,5};
		for(int i=0; i<p.length;i++)
			if(p[i] != puzzle[i]){
				count++;
			}
		return count;
	}
	
	// *manhattanCost(): Method to calculate cost of number of squares from desired location of each tile.(Heuristic-h2)
		public int manhattanCost(){
			int goal [] = {1,2,3,8,0,4,7,6,5};
			int diff = 0;
	        for (int i = 0; i < puzzle.length; i += 1)
	            for (int j = 0; j < goal.length; j += 1)
	                if (puzzle[i] == goal[j])
	                    diff = diff + ((Math.abs(i % 3 - j % 3)) + Math.abs(i / 3 + j / 3));
	        return diff;
		}
	
//**********************************************************************
// Making a heuristic of your own h(3)
// In this heuristic, I assign costs to a node/state/move based on the 
// possible number of moves it can make. i.e if a state can make 4 moves based on its tiles position(position of 0)
// it has got a better chance of finding a goal state. 
//  #4 moves = cost = 0;
//  #3 moves = cost = 1;
//  #3 moves = cost = 2;

// 		{ 1,2,4
//  	  7,0,5    cost = 0, since there are 4 possible moves  
//   	 8,3,6 }
		

//	 	{ 1,0,4
//	      7,2,5    cost = 1, since there are 3 possible moves  
//	      8,3,6 } 


//	 	{ 0,2,4
//	      7,1,5    cost = 2, since there are 2 possible moves  
//	      8,3,6 } 
		
		public int heuristic3Cost(){
			int cost=0,pos_0=0;
			for(int i=0; i<puzzle.length; i++){
				if(puzzle[i] == 0)
					pos_0=i;
			}
			if(pos_0%2==1) {
				cost = 1;
			}
			else if(pos_0==4) {
				cost = 0;
			}
			else cost = 2;
			return cost;
		}
		
	
	// *PrintPuzzle(String movement): print puzzle and movement
	public void PrintPuzzle(String movement)
	{
		
		int x =0;
		System.out.print("Move="+movement+" | ");
		System.out.print("Cost="+cost+" | ");
		System.out.print("Total Cost="+totalCost+" | ");
		System.out.println("Depth=" + nodeDepth); 
		for(int i=0; i<3; i++){
			for (int j=0; j<3; j++){
				System.out.print(puzzle[x]+" ");
				x++;
			}
			System.out.println();
		}
	}	
}
