import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Puzzle {
	public static void main(String [] args){
		
		int easy[] = {1,3,4,8,6,2,7,0,5};
		int medium[] = {2,8,1,0,4,3,7,6,5};
		int hard[] = {5,6,7,4,0,8,3,2,1};
		 
		// User Display.
		 BufferedReader myReader = new BufferedReader(new InputStreamReader(System.in)); 
	        
	     System.out.println("Enter Difficulty Level:" );
	     System.out.println("1 - Easy");
	     System.out.println("2 - Medium");
	     System.out.println("3 - Hard");
	     System.out.println();    
	     Node startnode = null;
	       
	     try {
			String difficultyLevel = myReader.readLine();
				switch(difficultyLevel)
			     {
				     case "1":
				    	 startnode = new Node(easy);
				    	 break;
				    	 
				     case "2":
				    	 startnode = new Node(medium);
				    	 break;
				    	 
				     case "3":
				    	 startnode = new Node(hard);
				    	 break;
				    	 
				     default:
				    	 startnode = new Node(easy);
				    	 break;
			     }
				System.out.println("You chose "+difficultyLevel+" option");
				System.out.println("");
				
	     	}
		 catch (IOException e) {
			// TODO Auto-generated catch block
			 		e.printStackTrace();
		 		} 
	     
		SearchAlgorithms sa = new SearchAlgorithms();
		
	     System.out.println("Enter ALgorithm:" );
	     System.out.println("1 - Breadth First Search");
	     System.out.println("2 - Depth First Search");
	     System.out.println("3 - Iterative Deepening");
	     System.out.println("4 - Uniform Cost Search");
	     System.out.println("5 - Best First Search");
	     System.out.println("6 - A*1");
	     System.out.println("7 - A*2");
	     System.out.println("8 - A*3");
	     
	     System.out.println();    
	     List<Node> goalPath = null;
	        
	     try {
			String algorithm = myReader.readLine();
			System.out.println("You chose "+algorithm+" option");
			System.out.println("Running the algorithm now");
			System.out.println();
			
				switch(algorithm)
			     {
				     case "1":
				    	 goalPath = sa.BFS(startnode);
				    	 break;
				    	 
				     case "2":
				    	 goalPath = sa.DFS(startnode);
				    	 break;
				    	 
				     case "3":
				    	 goalPath = sa.IDA(startnode,10);
				    	 break;
				    	 
				     case "4":
				    	 goalPath = sa.UCS(startnode);
				    	 break;
				    	 
				     case "5":
				    	 goalPath = sa.BestFS(startnode);
				    	 break;
				    	 
				     case "6":
				    	 goalPath = sa.Astar1(startnode);
				    	 break;
				    	 
				     case "7":
				    	 goalPath = sa.Astar2(startnode);
				    	 break;
				    	 
				     case "8":
				    	 goalPath = sa.Astar3(startnode);
				    	 break;
			     }
				
				
	     	}
		 catch (IOException e) {
			// TODO Auto-generated catch block
			 		e.printStackTrace();
		 		} 
	     
		
			// *Check if start node is goal. If goal found print the solution.
			if(goalPath.isEmpty() && startnode.isGoal())
				{
				
				System.out.println("Goal Path Found -- Root Node is the goal");
				}
			else if(!goalPath.isEmpty())
			{
				System.out.println("Goal Path Found");
				System.out.println("");
				System.out.println("PERFORMANCE MEASURES");
		        System.out.println("Time = " + sa.time);
		        System.out.println("Space = " + sa.maxTraverseList);
		        System.out.println("Length = " + goalPath.get(0).getDepth());
		        System.out.println("Cost = " + goalPath.get(0).getTotalCost());
		        System.out.println("");
				System.out.print("PATH FROM ROOT => GOAL");
				System.out.println("");
				for(int i=goalPath.size()-1; i>=0; i--){
					Node x = goalPath.get(i);
					String y = x.move;
					System.out.println("");
					x.PrintPuzzle(y);	
				}	
			}
			else{
				System.out.println("Goal Path not found");	
			} 
	}	
}