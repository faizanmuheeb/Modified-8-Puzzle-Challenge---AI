import java.util.*;

public class SearchAlgorithms {

	public int maxTraverseList = 0;
	public int time =0;
	
	public List<Node> BFS(Node root){
		
		List<Node> traverseList = new LinkedList<Node>();  	// traverseList stores the next states(children) to expand. 
		List<Node> visitedList = new LinkedList<Node>();	// visitedList stores the nodes visited in the order to reach goal state.
		List<Node> pathList = new LinkedList<Node>();		// pathList stores the path from root state to goal state.
		boolean isGoal = false;
		traverseList.add(root);								// Add first node (root) to the traverseList.
		root.setParent(null);									
		
		/* If traverseList has nodes to expand & goal not yet reached then .... */
		while(isGoal != true && traverseList.size() > 0) {	
			Node currentNode = traverseList.get(0); 	
			visitedList.add(currentNode);			// Get 1st node from traverseList and push it to visitedList 
			traverseList.remove(0); 				// Remove the just visited node from traverseList
			time++;
			
			if(currentNode.isGoal()){
				currentNode.PrintPuzzle(null);							// Check if goal
				isGoal = true; 
				System.out.println("Goal Found. Root is the goal");
			}
			else {
			currentNode.ExpandCurrentNode();		// Calls the method to apply moves on the currentNode			
			
			for(int i=0; i<currentNode.children.size(); i++) 
			{
				Node currentChild = currentNode.children.get(i);
				traverseList.add(currentChild);						// Nodes are expanded and children stored into traverseList.
				currentChild.setParent(currentNode);
				currentChild.setDepth(currentNode.getDepth()+1);
				currentChild.totalCost = currentNode.totalCost + currentChild.cost;    // Update depth and total cost.
				
				if(currentChild.isGoal()){
					System.out.println("**********Breadth-First Search******************");
					System.out.println("Goal Found");
					isGoal = true; 
					TracePath(currentChild,pathList);
				}
				
				//traverseList does not contain current child and visitedList contains current child then add it to traverseList.
				if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList)){
					traverseList.add(currentChild);
					if(currentChild.isGoal()) isGoal = true; 		// Check if newly added node is goal.
			}
			
			int size = traverseList.size()+1;
			if(size>maxTraverseList){
				maxTraverseList = size;
			}
			}
			}
		}
		return pathList;
	}

//*******************************************************************************************************	

	//*Contains(Node node, List<Node> list): Checks if a node is already present in the given list.
	public boolean Contains(Node node, List<Node> list)
	{
		boolean isContains = false;
		Iterator<Node> listIT = list.iterator();
		while(listIT.hasNext())
		{
			Node x = listIT.next();
			if(x.IsEqualPuzzle(node.puzzle)){
				isContains = true;
			}
		}
		return isContains;
	}

//*******************************************************************************************************

	// *TracePath(Node node, List<Node> pathList): Traces the path from goal node to the root node.
	public void TracePath(Node node, List<Node> pathList){
		Node current = node; 
		pathList.add(current);
		while(current.getParent() != null){
			current = current.getParent();
			pathList.add(current);
		}
		
	}
	
//******************************************************************************************************************************	
// Depth-First Search Algorithm.
	
	
	public List<Node> DFS(Node root){

		List<Node> traverseList = new LinkedList<Node>();
		List<Node> visitedList = new LinkedList<Node>();
		List<Node> pathList = new LinkedList<Node>();
		boolean isGoal = false;
		traverseList.add(root);
		root.setParent(null);
		root.move = null;
		
		/* If traverseList has nodes to expand & goal not yet reached then .... */
		while(isGoal != true && traverseList.size() > 0) {
			Node currentNode = traverseList.get(0);			//get first element from traverse list
			visitedList.add(currentNode);					//add to visited list
			if(currentNode.isGoal())
			{
				System.out.println("**********DFS******************");
				System.out.println("Goal Found");
				isGoal = true; 
				TracePath(currentNode,pathList);
			}
			
			traverseList.remove(0); 				//remove value at index 0 from traverse list
			time++;
			currentNode.ExpandCurrentNode();   		 //Expand current node by calling the move methods.
			
			// Reverse for loop to add the the children to the front of the list in ORDER.
			for(int i=currentNode.children.size()-1; i>=0 ; i--)
			{
				
				Node currentChild = currentNode.children.get(i); 			//pick last child first
				currentChild.setParent(currentNode); 
				currentChild.setDepth(currentNode.getDepth()+1);
				currentChild.totalCost = currentNode.totalCost + currentChild.cost;
				if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList)) 
				traverseList.add(0, currentChild);  			// Add to the front of the list, so the children are selected for expansion

			}
						
			int size = traverseList.size()+1;
			if(size>maxTraverseList){
				maxTraverseList = size;
			}
		}
		return pathList;
	}
	
	
// ********************************************************************************************************
// Iterative Deepening Search. 
	
public List<Node> IDA(Node root, int maxDepth){
		
		List<Node> traverseList = new LinkedList<Node>();
		List<Node> visitedList = new LinkedList<Node>();
		List<Node> pathList = new LinkedList<Node>();
		boolean isGoal = false;
		traverseList.add(root);
		root.setParent(null);
		
		// For loop to limit the depth of the expansion of nodes.
		for(int d=0; d<maxDepth; d++) {
		
			/* If traverseList has nodes to expand & goal not yet reached then .... */
			while(isGoal != true && traverseList.size() > 0) {
			Node currentNode = traverseList.get(0);
			
			visitedList.add(currentNode);
			traverseList.remove(0);
			time++;
			
			// Expand current node is maxDepth not reached.
			if(currentNode.getDepth() < maxDepth) {
			currentNode.ExpandCurrentNode();
			
			for(int i=0; i<currentNode.children.size(); i++) 
			{
				Node currentChild = currentNode.children.get(i);
				traverseList.add(currentChild);
				currentChild.setParent(currentNode);
				currentChild.setDepth(currentNode.getDepth()+1);
				currentChild.totalCost = currentNode.totalCost + currentChild.cost;
				if(currentChild.isGoal()){
					System.out.println("**********IDA******************");
					System.out.println("Goal Found");
					isGoal = true; 
					TracePath(currentChild,pathList);
				}
				
				//traverse list contains current child and closed list contains current child then add it to open list
				if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList))
				traverseList.add(currentChild);	
				if(currentChild.isGoal()) isGoal = true;
			}
			}
			int size = traverseList.size()+1;
			if(size>maxTraverseList){
				maxTraverseList = size;
			}
			}
		}
		return pathList;
		
	}

//****************************************************************************************************************************************************
// Uniform Cost search.


public List<Node> UCS(Node root){
	
	List<Node> traverseList = new LinkedList<Node>();
	List<Node> visitedList = new LinkedList<Node>();
	List<Node> pathList = new LinkedList<Node>();
	boolean isGoal = false;
	traverseList.add(root);
	root.setParent(null);
	
	/* If traverseList has nodes to expand & goal not yet reached then .... */
	while(isGoal != true && traverseList.size() > 0) {
		Node currentNode = traverseList.get(0);
		visitedList.add(currentNode);
		traverseList.remove(0);
		time++;
		if(currentNode.isGoal()){
			currentNode.PrintPuzzle(null);
			isGoal = true; 
			System.out.println("Goal Found. Root is the goal");
		}
		else {
		currentNode.ExpandCurrentNode();
		
		for(int i=0; i<currentNode.children.size(); i++) 
		{
			Node currentChild = currentNode.children.get(i);
			currentChild.setParent(currentNode);
			currentChild.setDepth(currentNode.getDepth()+1);
			currentChild.totalCost = currentNode.totalCost + currentChild.cost;
			
			if(currentChild.isGoal()){
				System.out.println("**********UCS******************");
				System.out.println("Goal Found");
				isGoal = true; 
				visitedList.add(currentChild);
				TracePath(currentChild,pathList);
			}
			
			//traverse list contains current child and closed list contains current child then add it to open list
			if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList))
			{
			traverseList.add(currentChild);
			if(currentChild.isGoal()) isGoal = true;
			sortList(traverseList); 			// Sort List based on the cost of the moves.
			}
			
		}
	
		int size = traverseList.size()+1;
		if(size>maxTraverseList)
		{
			maxTraverseList = size;
		}
		}
	}
	return pathList;
}

//*****************************************************************************************************
// Method sortList(List<Node> list): sort a list based on the cost of the node.
	public void sortList(List<Node> list)
	{
		for (int i = 0; i < list.size()-1 ; i++)
		{
			int min_idx = i;
			
			// Compare the costs of each element to one another.
			for (int j = i+1; j < list.size(); j++)
				if (list.get(j).getTotalCost() < list.get(min_idx).getTotalCost())
					min_idx = j;
		
			// Swap the minimum element with the first element.
			Node temp = list.get(min_idx);
			list.set(min_idx, list.get(i));
			list.set(i, temp);
		}
	}
	 
//************************************************************************************************************
// Best first search.
	
	public List<Node> BestFS(Node root){
		
		List<Node> traverseList = new LinkedList<Node>();
		List<Node> visitedList = new LinkedList<Node>();
		List<Node> pathList = new LinkedList<Node>();
		boolean isGoal = false;
		traverseList.add(root);
		root.setParent(null);
		
		
		//System.out.println("traverse list"+traverseList.get(0).puzzle);
		
		while(isGoal != true && traverseList.size() > 0) {
			Node currentNode = traverseList.get(0);
			visitedList.add(currentNode);
			traverseList.remove(0);
			time++;
			
			if(currentNode.isGoal())
			{
				currentNode.PrintPuzzle(null);
				isGoal = true; 
				System.out.println("Goal Found. Root is the goal");
			}
			else {
			currentNode.ExpandCurrentNode();
			
			for(int i=0; i<currentNode.children.size(); i++) 
			{
				Node currentChild = currentNode.children.get(i);
				currentChild.setParent(currentNode);
				currentChild.setDepth(currentNode.getDepth()+1);
				currentChild.setCost(currentChild.misMatchCost()); 					// Use h1 as the measure to sort traverseList
				currentChild.totalCost = currentNode.totalCost + currentChild.cost; // Update total cost.
				
				if(currentChild.isGoal()){
					System.out.println("**********Best First Search ******************");
					System.out.println("Goal Found");
					isGoal = true; 
					//path
					visitedList.add(currentChild);
					TracePath(currentChild,pathList);
				}
				//traverse list contains current child and closed list contains current child then add it to open list
				if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList))
				{
				traverseList.add(currentChild);
				if(currentChild.isGoal()) isGoal = true;
				sortList(traverseList);
				}
				
			}
			int size = traverseList.size()+1;
			if(size>maxTraverseList)
			{
				maxTraverseList = size;
			}
			}
		}
		
		return pathList;
		
	}

//************************* A*1 Search Algorithm **************************************************************************
	public List<Node> Astar1(Node root){
		
		List<Node> traverseList = new LinkedList<Node>();
		List<Node> visitedList = new LinkedList<Node>();
		List<Node> pathList = new LinkedList<Node>();
		boolean isGoal = false;
		traverseList.add(root);
		root.setParent(null);
		
		while(isGoal != true && traverseList.size() > 0) {
			Node currentNode = traverseList.get(0);
			visitedList.add(currentNode);
			traverseList.remove(0);
			time++;
			
			if(currentNode.isGoal())
			{
				currentNode.PrintPuzzle(null);
				isGoal = true; 
				System.out.println("Goal Found. Root is the goal");
			}
			else {
			currentNode.ExpandCurrentNode();
			
			for(int i=0; i<currentNode.children.size(); i++) 
			{
				Node currentChild = currentNode.children.get(i);
				//traverseList.add(currentChild);
				currentChild.setParent(currentNode);
				currentChild.setDepth(currentNode.getDepth()+1);
				currentChild.setCost(currentChild.misMatchCost() + currentChild.getCost()); //use h1 + cost->  (h(n) + g(n)) 
				currentChild.totalCost = currentNode.totalCost + currentChild.cost;
				
				if(currentChild.isGoal()){
					System.out.println("**********A*1 Search ******************");
					System.out.println("Goal Found");
					isGoal = true; 
					//path
					visitedList.add(currentChild);
					TracePath(currentChild,pathList);
				}
				//traverse list contains current child and closed list contains current child then add it to open list
				if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList))
				{
				traverseList.add(currentChild);
				if(currentChild.isGoal()) isGoal = true;
				sortList(traverseList);
				}
				
			}
		
			int size = traverseList.size()+1;
			if(size>maxTraverseList)
			{
				maxTraverseList = size;
			}
			}
		}
		
		
		return pathList;	
		
	}

	//************************* A*2 Search Algorithm **************************************************************************
		public List<Node> Astar2(Node root){
			
			List<Node> traverseList = new LinkedList<Node>();
			List<Node> visitedList = new LinkedList<Node>();
			List<Node> pathList = new LinkedList<Node>();
			boolean isGoal = false;
			traverseList.add(root);
			root.setParent(null);
			
			
			//System.out.println("traverse list"+traverseList.get(0).puzzle);
			
			while(isGoal != true && traverseList.size() > 0) {
				Node currentNode = traverseList.get(0);
				visitedList.add(currentNode);
				traverseList.remove(0);
				time++;
				if(currentNode.isGoal())
				{
					//System.out.println("depth = 0");
					//System.out.println(" no of expansion = 0");
					currentNode.PrintPuzzle(null);
					isGoal = true; 
					System.out.println("Goal Found. Root is the goal");
				}
				else {
				currentNode.ExpandCurrentNode();
				
				for(int i=0; i<currentNode.children.size(); i++) 
				{
					Node currentChild = currentNode.children.get(i);
					//traverseList.add(currentChild);
					currentChild.setParent(currentNode);
					currentChild.setDepth(currentNode.getDepth()+1);
					currentChild.setCost(currentChild.manhattanCost() + currentChild.getCost());
					currentChild.totalCost = currentNode.totalCost + currentChild.cost;
					
					if(currentChild.isGoal()){
						System.out.println("**********A*2 Search using Manhattan distance ******************");
						System.out.println("Goal Found");
						isGoal = true; 
						//path
						visitedList.add(currentChild);
						TracePath(currentChild,pathList);
					}
					//traverse list contains current child and closed list contains current child then add it to open list
					if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList))
					{
					traverseList.add(currentChild);
					if(currentChild.isGoal()) isGoal = true;
					sortList(traverseList);
					}
					
				}
			
				int size = traverseList.size()+1;
				if(size>maxTraverseList)
				{
					maxTraverseList = size;
				}
				}
			}
			
			
			return pathList;	
			
		}
//**********************************************************************************************************
//A*3 Search Algorithm
		
		
		public List<Node> Astar3(Node root){
			
			List<Node> traverseList = new LinkedList<Node>();
			List<Node> visitedList = new LinkedList<Node>();
			List<Node> pathList = new LinkedList<Node>();
			boolean isGoal = false;
			traverseList.add(root);
			root.setParent(null);
			
			while(isGoal != true && traverseList.size() > 0) {
				Node currentNode = traverseList.get(0);
				visitedList.add(currentNode);
				traverseList.remove(0);
				time++;
				
				if(currentNode.isGoal())
				{
					currentNode.PrintPuzzle(null);
					isGoal = true; 
					System.out.println("Goal Found. Root is the goal");
				}
				else {
				currentNode.ExpandCurrentNode();
				
				for(int i=0; i<currentNode.children.size(); i++) 
				{
					Node currentChild = currentNode.children.get(i);
					currentChild.setParent(currentNode);
					currentChild.setDepth(currentNode.getDepth()+1);
					currentChild.setCost(currentChild.heuristic3Cost() + currentChild.getCost()); // set cost
					currentChild.totalCost = currentNode.totalCost + currentChild.cost;
					
					if(currentChild.isGoal()){
						System.out.println("**********A*2 Search using Manhattan distance ******************");
						System.out.println("Goal Found");
						isGoal = true; 
						visitedList.add(currentChild);
						TracePath(currentChild,pathList);
					}
					//traverse list contains current child and closed list contains current child then add it to open list
					if(!Contains(currentChild, traverseList) && !Contains(currentChild, visitedList))
					{
					traverseList.add(currentChild);
					if(currentChild.isGoal()) isGoal = true;
					sortList(traverseList); 			// sort list based on the costs.
					}
					
				}
			
				int size = traverseList.size()+1;
				if(size>maxTraverseList)
				{
					maxTraverseList = size;
				}
				}
			}			
			return pathList;	
			
		}

} // End Main


